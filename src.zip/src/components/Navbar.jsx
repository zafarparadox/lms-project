import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

function Navbar() {
  const { dark, setDark } = useContext(ThemeContext);

  return (
    <div className="bg-white/70 backdrop-blur-md px-6 py-4 flex justify-between items-center border-b shadow-sm dark:bg-slate-900">

      <div>
        <h1 className="text-xl font-semibold text-gray-800 dark:text-white">
          Dashboard
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-300">
          Welcome back, User 👋
        </p>
      </div>

      <div className="flex items-center gap-4">

        {/* DARK MODE BUTTON */}
        <button
          onClick={() => setDark(!dark)}
          className="px-3 py-1 bg-gray-200 rounded dark:bg-gray-700 dark:text-white"
        >
          {dark ? "Light" : "Dark"}
        </button>

        <input
          type="text"
          placeholder="Search..."
          className="px-3 py-2 rounded-lg bg-gray-100 dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
        />

        <div className="w-9 h-9 bg-blue-600 text-white flex items-center justify-center rounded-full font-semibold shadow-md">
          U
        </div>

      </div>

    </div>
  );
}

export default Navbar;