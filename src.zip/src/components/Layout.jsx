import Sidebar from "./Sidebar";
import TeacherSidebar from "./TeacherSidebar";
import AdminSidebar from "./AdminSidebar";

function Layout({ children }) {
  const role = localStorage.getItem("role");

  return (
    <div className="flex">

      {role === "admin" ? (
        <AdminSidebar />
      ) : role === "teacher" ? (
        <TeacherSidebar />
      ) : (
        <Sidebar />
      )}

      <div className="flex-1 p-4 sm:p-6 bg-gray-100 dark:bg-slate-900 min-h-screen transition">
        {children}
      </div>

    </div>
  );
}

export default Layout;