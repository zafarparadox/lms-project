import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Courses from "./pages/Courses";
import CourseDetail from "./pages/CourseDetail";
import AssignmentPage from "./pages/AssignmentPage";
import ProfilePage from "./pages/ProfilePage";
import QuizPage from "./pages/QuizPage";

import TeacherDashboard from "./pages/TeacherDashboard";
import TeacherCourse from "./pages/TeacherCourse";
import TeacherVideo from "./pages/TeacherVideo";
import TeacherAssignment from "./pages/TeacherAssignment";
import CheckAssignment from "./pages/CheckAssignment";
import TeacherQuiz from "./pages/TeacherQuiz";
import AdminDashboard from "./pages/AdminDashboard";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/course-detail" element={<CourseDetail />} />
        <Route path="/assignments" element={<AssignmentPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/quiz" element={<QuizPage />} />
        <Route path="/teacher-quiz" element={<TeacherQuiz />} />
        <Route path="/teacher-dashboard" element={<TeacherDashboard />} />
        <Route path="/teacher-course" element={<TeacherCourse />} />
        <Route path="/teacher-video" element={<TeacherVideo />} />
        <Route path="/teacher-assignment" element={<TeacherAssignment />} />
        <Route path="/check-assignment" element={<CheckAssignment />} />
        <Route path="/teacher-quiz" element={<TeacherQuiz />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;