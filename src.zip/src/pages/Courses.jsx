import Layout from "../components/Layout";
import { useNavigate } from "react-router-dom";

function Courses() {
  const navigate = useNavigate(); // ✅ Page change karne ke liye

  // 👉 Course click - Ye aapko direct CourseDetail page par le jayega
  const openCourse = (key) => {
    navigate("/course-detail", { state: { course: key } });
  };

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">
        My Courses 📚
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* HTML COURSE CARD */}
        <div
          onClick={() => openCourse("html")}
          className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-lg cursor-pointer hover:scale-105 hover:shadow-xl transition-all duration-300 border border-transparent hover:border-blue-500"
        >
          <div className="text-4xl mb-3">🌐</div>
          <h2 className="text-lg font-bold text-gray-800 dark:text-white">
            HTML Course
          </h2>
          <p className="text-gray-500 dark:text-gray-300 text-sm mt-1">
            Learn HTML step by step from scratch.
          </p>
        </div>

        {/* NETWORKING COURSE CARD */}
        <div
          onClick={() => openCourse("networking")}
          className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-lg cursor-pointer hover:scale-105 hover:shadow-xl transition-all duration-300 border border-transparent hover:border-green-500"
        >
          <div className="text-4xl mb-3">📡</div>
          <h2 className="text-lg font-bold text-gray-800 dark:text-white">
            Networking Course
          </h2>
          <p className="text-gray-500 dark:text-gray-300 text-sm mt-1">
            Master the basics of computer networking.
          </p>
        </div>

      </div>
    </Layout>
  );
}

export default Courses;