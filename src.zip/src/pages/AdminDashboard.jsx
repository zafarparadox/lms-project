import Layout from "../components/Layout";

function AdminDashboard() {
  return (
    <Layout>
      <div className="px-4 py-6 max-w-7xl mx-auto">

        <h1 className="text-2xl font-bold mb-6 dark:text-white">
          🛠 Admin Dashboard
        </h1>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">

          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow">
            <h2>Total Users</h2>
            <p className="text-xl font-bold">120</p>
          </div>

          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow">
            <h2>Courses</h2>
            <p className="text-xl font-bold">25</p>
          </div>

          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow">
            <h2>Teachers</h2>
            <p className="text-xl font-bold">10</p>
          </div>

        </div>

      </div>
    </Layout>
  );
}

export default AdminDashboard;