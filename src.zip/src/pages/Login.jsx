import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (!email || !password) {
      alert("Enter email & password");
      return;
    }

    if (email === "admin@gmail.com") {
      localStorage.setItem("role", "admin");
      navigate("/admin-dashboard");
    } else if (email === "teacher@gmail.com") {
      localStorage.setItem("role", "teacher");
      navigate("/teacher-dashboard");
    } else {
      localStorage.setItem("role", "student");
      navigate("/dashboard");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-gray-900 to-black px-4">

      <div className="w-full max-w-md bg-white/10 backdrop-blur-lg border border-white/20 p-6 sm:p-8 rounded-2xl shadow-2xl text-white">

        <h2 className="text-2xl sm:text-3xl font-bold text-center mb-6">
          LMS Login
        </h2>

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full p-3 mb-4 rounded-lg bg-white/20 border border-white/30 focus:ring-2 focus:ring-blue-500"
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full p-3 mb-4 rounded-lg bg-white/20 border border-white/30 focus:ring-2 focus:ring-blue-500"
        />

        <button
          onClick={handleLogin}
          className="w-full bg-blue-600 p-3 rounded-lg hover:bg-blue-700 transition"
        >
          Login
        </button>

        <p className="text-xs mt-4 text-center text-gray-300">
          Admin: admin@gmail.com <br />
          Teacher: teacher@gmail.com
        </p>

      </div>

    </div>
  );
}

export default Login;