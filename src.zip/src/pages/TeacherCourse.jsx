import { useState } from "react";
import Layout from "../components/Layout";

function TeacherCourse() {
  const [courseTitle, setCourseTitle] = useState("");
  const [description, setDescription] = useState("");
  const [courses, setCourses] = useState([]);

  const handleCreate = () => {
    if (!courseTitle) {
      alert("Enter course title");
      return;
    }

    const newCourse = {
      title: courseTitle,
      description,
    };

    setCourses([...courses, newCourse]);
    setCourseTitle("");
    setDescription("");
  };

  return (
    <Layout>
      <div className="px-4 md:px-6 py-6 max-w-5xl mx-auto">

        {/* HEADER */}
        <h1 className="text-xl sm:text-2xl font-bold mb-6 text-gray-800 dark:text-white">
          📚 Create Course
        </h1>

        {/* FORM */}
        <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow border mb-6">

          <input
            type="text"
            placeholder="Course Title"
            value={courseTitle}
            onChange={(e) => setCourseTitle(e.target.value)}
            className="w-full p-3 mb-4 rounded-lg border bg-white text-gray-800 dark:bg-slate-700 dark:text-white"
          />

          <textarea
            placeholder="Course Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-3 mb-4 rounded-lg border bg-white text-gray-800 dark:bg-slate-700 dark:text-white"
          />

          <button
            onClick={handleCreate}
            className="px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
          >
            ➕ Create Course
          </button>

        </div>

        {/* COURSE LIST */}
        <div className="grid sm:grid-cols-2 gap-4">

          {courses.length === 0 && (
            <p className="text-gray-500">No courses created yet</p>
          )}

          {courses.map((course, i) => (
            <div
              key={i}
              className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow border"
            >
              <h2 className="font-bold text-gray-800 dark:text-white">
                {course.title}
              </h2>
              <p className="text-sm text-gray-500 mt-2">
                {course.description}
              </p>
            </div>
          ))}

        </div>

      </div>
    </Layout>
  );
}

export default TeacherCourse;